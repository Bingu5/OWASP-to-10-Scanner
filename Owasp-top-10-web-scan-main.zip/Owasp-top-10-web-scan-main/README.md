# OWASP Web Scanner

### Usage
- docker-compose up
- Then run owasap.py